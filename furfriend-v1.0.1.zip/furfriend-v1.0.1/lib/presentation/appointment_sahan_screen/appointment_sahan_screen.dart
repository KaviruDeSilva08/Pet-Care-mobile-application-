import 'package:furfriend/widgets/custom_icon_button.dart';
import 'package:furfriend/widgets/custom_elevated_button.dart';

import 'package:flutter/material.dart';
import 'package:furfriend/core/app_export.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class AppointmentSahanScreen extends StatefulWidget {
  const AppointmentSahanScreen({Key? key}) : super(key: key);

  @override
  _AppointmentSahanScreenState createState() => _AppointmentSahanScreenState();
}

class _AppointmentSahanScreenState extends State<AppointmentSahanScreen> {
  List<String> appointments = [];

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        extendBody: true,
        extendBodyBehindAppBar: true,
        body: Container(
          width: SizeUtils.width,
          height: SizeUtils.height,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment(0.5, 0),
              end: Alignment(0.5, 1),
              colors: [appTheme.blue900, appTheme.blue200],
            ),
          ),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildFortyFive(context),
                SizedBox(height: 1.v),
                Divider(color: appTheme.whiteA700.withOpacity(0.75)),
                SizedBox(height: 5.v),
                Text("___________________Appointments__________________", style: theme.textTheme.headlineSmall),
                SizedBox(height: 2.v),
                Divider(color: appTheme.whiteA700.withOpacity(0.75)),
                SizedBox(height: 27.v),
                SizedBox(
                  height: 783.v,
                  width: 418.h,
                  child: Stack(
                    alignment: Alignment.bottomRight,
                    children: [
                      Align(
                        alignment: Alignment.bottomLeft,
                        child: SizedBox(
                          height: 269.v,
                          width: 211.h,
                          child: Stack(
                            alignment: Alignment.topRight,
                            children: [
                              CustomImageView(
                                imagePath: ImageConstant.imgEllipse6,
                                width: 211.h,
                                alignment: Alignment.center,
                              ),
                              Align(
                                alignment: Alignment.topRight,
                                child: Padding(
                                  padding: EdgeInsets.fromLTRB(29.h, 80.v, 11.h, 107.v),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Padding(
                                        padding: EdgeInsets.only(top: 28.v),
                                        child: CustomIconButton(
                                          height: 54.v,
                                          width: 57.h,
                                          padding: EdgeInsets.all(9.h),
                                          child: CustomImageView(
                                            imagePath: ImageConstant.imgGroup1,
                                          ),
                                        ),
                                      ),
                                      CustomElevatedButton(
                                        width: 83.h,
                                        text: "Remove",
                                        margin: EdgeInsets.only(bottom: 52.v),
                                        onPressed: () {
                                          _showRemoveAppointmentDialog(context);
                                        },
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      Align(
                        alignment: Alignment.bottomRight,
                        child: Padding(
                          padding: EdgeInsets.only(right: 9.h, bottom: 107.v),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              CustomElevatedButton(
                                width: 83.h,
                                text: "Add",
                                margin: EdgeInsets.only(bottom: 52.v),
                                onPressed: () {
                                  _showAddAppointmentDialog(context);
                                },
                              ),
                              Padding(
                                padding: EdgeInsets.only(left: 48.h, top: 28.v),
                                child: CustomIconButton(
                                  height: 54.v,
                                  width: 57.h,
                                  padding: EdgeInsets.all(9.h),
                                  onTap: () {
                                    onTapBtnIconButton(context);
                                  },
                                  child: CustomImageView(
                                    imagePath: ImageConstant.imgGroup2,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                appointments.isNotEmpty
                    ? Column(
                  children: appointments.map((appointment) {
                    return Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Container(
                        width: double.infinity,
                        padding: EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Text(
                          appointment,
                          style: TextStyle(
                            fontSize: 20,
                            color: Colors.black,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    );
                  }).toList(),
                )
                    : SizedBox(),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildFortyFive(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: EdgeInsets.only(left: 13.h),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: EdgeInsets.only(top: 47.v, bottom: 80.v),
                child: CustomIconButton(
                  height: 29.adaptSize,
                  width: 29.adaptSize,
                  padding: EdgeInsets.all(2.h),
                  child: CustomImageView(imagePath: ImageConstant.imgBack),
                ),
              ),
              Spacer(),
              CustomImageView(
                imagePath: ImageConstant.imgFurfriendW1,
                height: 104.v,
                margin: EdgeInsets.only(top: 52.v),
              ),
              CustomImageView(
                imagePath: ImageConstant.imgEllipse7,
                height: 95.v,
                margin: EdgeInsets.only(left: 7.h, bottom: 61.v),
              ),
            ],
          ),
        ),
        appointments.isNotEmpty
            ? Column(
          children: appointments.map((appointment) {
            return Padding(
              padding: const EdgeInsets.all(8.0),
              child: Container(
                width: double.infinity,
                padding: EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text(
                  appointment,
                  style: TextStyle(
                    fontSize: 20,
                    color: Colors.black,
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
            );
          }).toList(),
        )
            : SizedBox(),
      ],
    );
  }

  void _showAddAppointmentDialog(BuildContext context) {
    TextEditingController nameController = TextEditingController();
    DateTime? selectedDate;

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Add Appointment'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              TextField(
                controller: nameController,
                decoration: InputDecoration(
                  labelText: 'Appointment Name',
                ),
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: () async {
                  final DateTime? pickedDate = await showDatePicker(
                    context: context,
                    initialDate: DateTime.now(),
                    firstDate: DateTime.now(),
                    lastDate: DateTime(DateTime.now().year + 5),
                  );
                  if (pickedDate != null) {
                    setState(() {
                      selectedDate = pickedDate;
                    });
                  }
                },
                child: Text(selectedDate == null
                    ? 'Select Date'
                    : 'Date Selected : ${selectedDate.toString().split(' ')[0]}'),
              ),
            ],
          ),
          actions: <Widget>[
            ElevatedButton(
              onPressed: () {
                Navigator.of(context).pop(false);
              },
              child: Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () async {
                if (nameController.text.isNotEmpty && selectedDate != null) {
                  try {
                    await FirebaseFirestore.instance.collection('appointments').add({
                      'name': nameController.text,
                      'date': selectedDate,
                    });
                    Navigator.of(context).pop(true);
                  } catch (e) {
                    print('Failed to add appointment: $e');
                    Navigator.of(context).pop(false);
                  }
                }
              },
              child: Text('Add'),
            ),
          ],
        );
      },
    ).then((result) {
      if (result != null && result) {
        String appointment = '${nameController.text} - ${selectedDate.toString().split(' ')[0]}';
        setState(() {
          appointments.add(appointment);
        });
      }
    });
  }




  void _showRemoveAppointmentDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Remove Appointment'),
          content: Text('Are you sure you want to remove this appointment?'),
          actions: <Widget>[
            ElevatedButton(
              onPressed: () {
                Navigator.of(context).pop(false);
              },
              child: Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.of(context).pop(true);
              },
              child: Text('Remove'),
            ),
          ],
        );
      },
    ).then((result) {
      if (result != null && result) {
        setState(() {
          appointments.removeLast();
        });
      }
    });
  }

  /// Navigates to the notificationsSahanScreen when the action is triggered.
  onTapBtnIconButton(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.notificationsSahanScreen);
  }
}

