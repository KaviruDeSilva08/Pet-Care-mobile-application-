import 'package:flutter/material.dart';
import 'package:furfriend/core/app_export.dart';

// ignore: must_be_immutable
class SixtysixItemWidget extends StatelessWidget {
  const SixtysixItemWidget({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: 9.h,
        vertical: 6.v,
      ),
      decoration: AppDecoration.fillWhiteA.copyWith(
        borderRadius: BorderRadiusStyle.roundedBorder30,
      ),
      child: Row(
        children: [
          Container(
            height: 50.adaptSize,
            width: 50.adaptSize,
            margin: EdgeInsets.only(top: 1.v),
            decoration: BoxDecoration(
              color: appTheme.gray500E5,
              borderRadius: BorderRadius.circular(
                25.h,
              ),
            ),
          ),
          Expanded(
            child: Padding(
              padding: EdgeInsets.only(
                left: 10.h,
                top: 13.v,
                bottom: 7.v,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(
                    width: 92.h,
                    child: Divider(),
                  ),
                  SizedBox(height: 9.v),
                  SizedBox(
                    width: 289.h,
                    child: Row(
                      children: [
                        SizedBox(
                          width: 65.h,
                          child: Divider(),
                        ),
                        Spacer(),
                        CustomImageView(
                          imagePath: ImageConstant.imgLine26,
                          height: 4.v,
                        ),
                        CustomImageView(
                          imagePath: ImageConstant.imgLine26,
                          height: 4.v,
                          margin: EdgeInsets.only(left: 10.h),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 8.v),
                  CustomImageView(
                    imagePath: ImageConstant.imgLine26,
                    height: 4.v,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
