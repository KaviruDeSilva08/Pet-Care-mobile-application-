import 'package:flutter/material.dart';
import 'package:furfriend/core/app_export.dart';

// ignore: must_be_immutable
class SixtyfiveItemWidget extends StatelessWidget {
  const SixtyfiveItemWidget({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: 9.h,
        vertical: 3.v,
      ),
      decoration: AppDecoration.fillWhiteA.copyWith(
        borderRadius: BorderRadiusStyle.roundedBorder30,
      ),
      child: Row(
        children: [
          CustomImageView(
            imagePath: ImageConstant.imgUser11,
            width: 54.h,
          ),
          Expanded(
            child: Padding(
              padding: EdgeInsets.only(
                left: 6.h,
                top: 16.v,
                bottom: 10.v,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(
                    width: 92.h,
                    child: Divider(),
                  ),
                  SizedBox(height: 9.v),
                  SizedBox(
                    width: 289.h,
                    child: Row(
                      children: [
                        SizedBox(
                          width: 65.h,
                          child: Divider(),
                        ),
                        Spacer(),
                        CustomImageView(
                          imagePath: ImageConstant.imgLine26,
                          height: 4.v,
                        ),
                        CustomImageView(
                          imagePath: ImageConstant.imgLine26,
                          height: 4.v,
                          margin: EdgeInsets.only(left: 10.h),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 8.v),
                  CustomImageView(
                    imagePath: ImageConstant.imgLine26,
                    height: 4.v,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
