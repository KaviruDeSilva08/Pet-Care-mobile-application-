import 'package:furfriend/widgets/custom_switch.dart';
import 'package:flutter/material.dart';
import 'package:furfriend/core/app_export.dart';

// ignore: must_be_immutable
class NotificationssahanItemWidget extends StatelessWidget {
  NotificationssahanItemWidget({Key? key})
      : super(
          key: key,
        );

  bool isSelectedSwitch = false;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 356.h,
      padding: EdgeInsets.symmetric(
        horizontal: 11.h,
        vertical: 6.v,
      ),
      decoration: AppDecoration.fillWhiteA.copyWith(
        borderRadius: BorderRadiusStyle.roundedBorder30,
      ),
      child: Row(
        children: [
          Container(
            height: 50.v,
            width: 47.h,
            margin: EdgeInsets.only(bottom: 1.v),
            decoration: BoxDecoration(
              color: appTheme.gray500E5,
              borderRadius: BorderRadius.circular(
                25.h,
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.only(
              left: 6.h,
              top: 13.v,
              bottom: 7.v,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  width: 86.h,
                  child: Divider(),
                ),
                SizedBox(height: 11.v),
                SizedBox(
                  width: 62.h,
                  child: Divider(),
                ),
                SizedBox(height: 8.v),
                CustomImageView(
                  imagePath: ImageConstant.imgLine26,
                  height: 4.v,
                ),
              ],
            ),
          ),
          Spacer(),
          CustomImageView(
            imagePath: ImageConstant.imgLine26,
            height: 4.v,
            margin: EdgeInsets.only(
              top: 25.v,
              bottom: 22.v,
            ),
          ),
          CustomSwitch(
            margin: EdgeInsets.fromLTRB(13.h, 14.v, 16.h, 14.v),
            value: isSelectedSwitch,
            onChange: (value) {
              isSelectedSwitch = value ?? false;
            },
          ),
        ],
      ),
    );
  }
}
