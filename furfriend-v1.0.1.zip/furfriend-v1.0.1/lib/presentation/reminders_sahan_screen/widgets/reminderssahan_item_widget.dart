import 'package:furfriend/widgets/custom_switch.dart';
import 'package:flutter/material.dart';
import 'package:furfriend/core/app_export.dart';

// ignore: must_be_immutable
class ReminderssahanItemWidget extends StatelessWidget {
  ReminderssahanItemWidget({Key? key})
      : super(
          key: key,
        );

  bool isSelectedSwitch = false;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 356.h,
      padding: EdgeInsets.symmetric(
        horizontal: 11.h,
        vertical: 6.v,
      ),
      decoration: AppDecoration.fillWhiteA.copyWith(
        borderRadius: BorderRadiusStyle.roundedBorder30,
      ),
      child: Row(
        children: [
          Container(
            height: 50.v,
            width: 47.h,
            margin: EdgeInsets.only(bottom: 1.v),
            decoration: BoxDecoration(
              color: appTheme.gray500E5,
              borderRadius: BorderRadius.circular(
                25.h,
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.only(
              left: 6.h,
              top: 13.v,
              bottom: 7.v,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  width: 86.h,
                  child: Divider(),
                ),
                SizedBox(height: 11.v),
                SizedBox(
                  width: 62.h,
                  child: Divider(),
                ),
                SizedBox(height: 8.v),
                CustomImageView(
                  imagePath: ImageConstant.imgLine26,
                  height: 4.v,
                ),
              ],
            ),
          ),
          Spacer(
            flex: 63,
          ),
          Padding(
            padding: EdgeInsets.symmetric(vertical: 3.v),
            child: SizedBox(
              height: 44.adaptSize,
              width: 44.adaptSize,
              child: CircularProgressIndicator(
                value: 0.5,
                backgroundColor: appTheme.whiteA700.withOpacity(0.43),
                color: appTheme.blue900.withOpacity(0.9),
              ),
            ),
          ),
          Spacer(
            flex: 36,
          ),
          CustomSwitch(
            margin: EdgeInsets.only(
              top: 14.v,
              right: 16.h,
              bottom: 14.v,
            ),
            value: isSelectedSwitch,
            onChange: (value) {
              isSelectedSwitch = value ?? false;
            },
          ),
        ],
      ),
    );
  }
}
