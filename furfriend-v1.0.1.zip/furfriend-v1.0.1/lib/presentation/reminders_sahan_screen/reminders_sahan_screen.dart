import 'package:furfriend/widgets/custom_icon_button.dart';
import 'widgets/reminderssahan_item_widget.dart';
import 'package:flutter/material.dart';
import 'package:furfriend/core/app_export.dart';

class RemindersSahanScreen extends StatelessWidget {
  const RemindersSahanScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        extendBody: true,
        extendBodyBehindAppBar: true,
        body: Container(
          width: SizeUtils.width,
          height: SizeUtils.height,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment(0.5, 0),
              end: Alignment(0.5, 1),
              colors: [
                appTheme.blue900,
                appTheme.blue200,
              ],
            ),
          ),
          child: SizedBox(
            width: double.maxFinite,
            child: SingleChildScrollView(
              child: Column(
                children: [
                  _buildSeventy(context),
                  SizedBox(height: 1.v),
                  Divider(
                    color: appTheme.whiteA700.withOpacity(0.75),
                  ),
                  SizedBox(height: 3.v),
                  Text(
                    "Notifications",
                    style: theme.textTheme.headlineSmall,
                  ),
                  SizedBox(height: 4.v),
                  Divider(
                    color: appTheme.whiteA700.withOpacity(0.75),
                  ),
                  SizedBox(height: 27.v),
                  // New Container for the white box
                  Container(
                    width: 400,
                    height: 50,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          "Appointment Name : Sahan",
                          style: TextStyle(
                            color: Colors.black,

                            fontSize: 10,
                          ),
                        ),
                        Text(
                          "Appointment Date : ",
                          style: TextStyle(
                            color: Colors.black,
                            fontSize: 10,
                          ),
                        ),
                      ],
                    ),
                  ),
                  // End of white box
                  SizedBox(
                    height: 783.v,
                    width: 418.h,
                    child: Stack(
                      alignment: Alignment.bottomRight,
                      children: [
                        Align(
                          alignment: Alignment.bottomLeft,
                          child: SizedBox(
                            height: 269.v,
                            width: 211.h,
                            child: Stack(
                              alignment: Alignment.centerLeft,
                              children: [
                                CustomImageView(
                                  imagePath: ImageConstant.imgEllipse61,
                                  width: 211.h,
                                  alignment: Alignment.center,
                                ),
                                Padding(
                                  padding: EdgeInsets.only(left: 29.h),
                                  child: CustomIconButton(
                                    height: 54.v,
                                    width: 57.h,
                                    padding: EdgeInsets.all(9.h),
                                    alignment: Alignment.centerLeft,
                                    child: CustomImageView(
                                      imagePath: ImageConstant.imgGroup1,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Align(
                          alignment: Alignment.bottomRight,
                          child: Container(
                            height: 54.v,
                            width: 57.h,
                            margin: EdgeInsets.only(
                              right: 9.h,
                              bottom: 107.v,
                            ),
                            child: Stack(
                              alignment: Alignment.center,
                              children: [
                                Align(
                                  alignment: Alignment.center,
                                  child: Container(
                                    height: 54.v,
                                    width: 57.h,
                                    decoration: BoxDecoration(
                                      color: appTheme.blue900.withOpacity(0.8),
                                      borderRadius: BorderRadius.circular(
                                        28.h,
                                      ),
                                      boxShadow: [
                                        BoxShadow(
                                          color: appTheme.black900
                                              .withOpacity(0.25),
                                          spreadRadius: 2.h,
                                          blurRadius: 2.h,
                                          offset: Offset(
                                            0,
                                            4,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                CustomImageView(
                                  imagePath: ImageConstant.imgGroup2,
                                  height: 36.adaptSize,
                                  width: 36.adaptSize,
                                  alignment: Alignment.center,
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildSeventy(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(left: 13.h),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: EdgeInsets.only(
              top: 47.v,
              bottom: 80.v,
            ),
            child: CustomIconButton(
              height: 29.adaptSize,
              width: 29.adaptSize,
              padding: EdgeInsets.all(2.h),
              child: CustomImageView(
                imagePath: ImageConstant.imgBack,
              ),
            ),
          ),
          Spacer(),
          CustomImageView(
            imagePath: ImageConstant.imgFurfriendW1,
            height: 104.v,
            margin: EdgeInsets.only(top: 52.v),
          ),
          CustomImageView(
            imagePath: ImageConstant.imgEllipse71,
            height: 95.v,
            margin: EdgeInsets.only(
              left: 7.h,
              bottom: 61.v,
            ),
          ),
        ],
      ),
    );
  }
}
