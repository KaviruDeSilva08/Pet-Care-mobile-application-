import 'package:flutter/material.dart';
import '../presentation/appointment_sahan_screen/appointment_sahan_screen.dart';
import '../presentation/reminders_sahan_screen/reminders_sahan_screen.dart';
import '../presentation/notifications_sahan_screen/notifications_sahan_screen.dart';
import '../presentation/app_navigation_screen/app_navigation_screen.dart';

class AppRoutes {
  static const String appointmentSahanScreen = '/appointment_sahan_screen';

  static const String remindersSahanScreen = '/reminders_sahan_screen';

  static const String notificationsSahanScreen = '/notifications_sahan_screen';

  static const String appNavigationScreen = '/app_navigation_screen';

  static Map<String, WidgetBuilder> routes = {
    appointmentSahanScreen: (context) => AppointmentSahanScreen(),
    remindersSahanScreen: (context) => RemindersSahanScreen(),
    notificationsSahanScreen: (context) => NotificationsSahanScreen(),
    appNavigationScreen: (context) => AppNavigationScreen()
  };
}
