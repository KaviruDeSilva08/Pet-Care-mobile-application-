class ImageConstant {
  // Image folder path
  static String imagePath = 'assets/images';

  // Appointment/Sahan images
  static String imgEllipse7 = '$imagePath/img_ellipse_7.png';

  static String imgEllipse6 = '$imagePath/img_ellipse_6.png';

  static String imgUser11 = '$imagePath/img_user_1_1.png';

  // Reminders/Sahan images
  static String imgEllipse795x100 = '$imagePath/img_ellipse_7_95x100.png';

  static String imgEllipse6269x211 = '$imagePath/img_ellipse_6_269x211.png';

  // Notifications/Sahan images
  static String imgEllipse71 = '$imagePath/img_ellipse_7_1.png';

  static String imgEllipse61 = '$imagePath/img_ellipse_6_1.png';

  // Common images
  static String imgBack = '$imagePath/img_back.svg';

  static String imgFurfriendW1 = '$imagePath/img_furfriend_w_1.png';

  static String imgGroup1 = '$imagePath/img_group_1.png';

  static String imgGroup2 = '$imagePath/img_group_2.png';

  static String imgLine26 = '$imagePath/img_line_26.svg';

  static String imgLine54 = '$imagePath/img_line_54.svg';

  static String imgLine54Blue900 = '$imagePath/img_line_54_blue_900.svg';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
