package com.furfriend.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
